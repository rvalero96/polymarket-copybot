# Polymarket Copy Trading Bot

Automated copy trading system over Polymarket prediction markets, running entirely on **GitHub Actions** — no server needed.

## How it works

| Cycle | Frequency | What it does |
|---|---|---|
| **Trading** | Every 2h | Scans tracked wallets, detects position changes, replicates in paper |
| **Discovery** | Every 6h | Ranks leaderboard traders, rotates roster automatically |
| **Report** | Daily 08:00 UTC | Generates P&L report in `reports/YYYY-MM-DD.md` |

State (SQLite) is committed to the `paper-state` branch between runs.

## Quick start

```bash
git clone https://github.com/YOUR_ORG/polymarket-copybot
cd polymarket-copybot
npm install
cp .env.example .env

# Run locally
node src/engine/simulator.js   # trading cycle
node src/discovery/ranker.js   # discovery cycle
node src/reports/daily.js      # generate report
```

## Repository setup (one-time)

1. Create repo on GitHub (can be private)
2. Go to **Settings → Actions → General** → enable "Read and write permissions"
3. Create `paper-state` branch: `git checkout -b paper-state && git push origin paper-state`
4. Push `main` — workflows activate automatically

## Project structure

```
├── .github/workflows/
│   ├── trading.yml       # 2h trading cycle
│   ├── discovery.yml     # 6h roster rotation
│   └── report.yml        # daily P&L report
├── src/
│   ├── engine/
│   │   ├── simulator.js  # paper trading execution (entry point)
│   │   └── signals.js    # position change detection
│   ├── services/polymarket/
│   │   ├── api.js        # Polymarket public API client
│   │   └── trading.js    # Phase 2: live execution stub
│   ├── discovery/
│   │   └── ranker.js     # wallet scoring & roster rotation
│   ├── reports/
│   │   └── daily.js      # markdown report generator
│   └── utils/
│       ├── db.js          # SQLite WASM wrapper + schema
│       └── logger.js      # structured JSON logger
├── config.js              # all tunable parameters
├── reports/               # generated daily reports (committed to main)
└── data/                  # state.db lives here (paper-state branch only)
```

## Tuning the strategy

All parameters are in `config.js` — no logic changes needed:

- `POSITION_SIZE_PCT` — how much bankroll per trade (default 5%)
- `MAX_OPEN_POSITIONS` — max concurrent positions (default 10)
- `FILTERS` — price range, liquidity, signal age, volume thresholds
- `DISCOVERY.MIN_WIN_RATE` / `MIN_ROI` — minimum bar to enter roster
- `SLIPPAGE_PCT` / `FEE_PCT` — cost simulation realism

## Team workflow

| Branch | Purpose |
|---|---|
| `main` | source code + daily reports |
| `paper-state` | SQLite DB snapshots (managed by Actions) |
| `feature/*` | each team member's work |

PRs always target `main`. The `paper-state` branch is managed exclusively by GitHub Actions — don't push there manually.

## Phase 2: Live trading

Once paper trading shows consistent profitability (≥2 weeks):

1. Create a wallet at [clob.polymarket.com](https://clob.polymarket.com) and deposit USDC via Polygon
2. Generate API credentials (CLOB_API_KEY, CLOB_API_SECRET, CLOB_API_PASSPHRASE)
3. Add secrets to **GitHub Settings → Secrets**: `PRIVATE_KEY`, `CLOB_API_KEY`, `CLOB_API_SECRET`, `CLOB_API_PASSPHRASE`
4. Set `TRADING_MODE=live` in `.github/workflows/trading.yml`
5. Implement `src/services/polymarket/trading.js` using `@polymarket/clob-client`

The discovery, scoring, and signal logic are identical in both phases — only the execution layer changes.
