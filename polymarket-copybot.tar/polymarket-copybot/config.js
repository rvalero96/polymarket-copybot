// ─── Central configuration ────────────────────────────────────────────────────
// Edit here to tune strategy. No logic changes needed.

export const CONFIG = {
  // Trading mode: 'paper' | 'live' (live requires Phase 2 secrets)
  TRADING_MODE: process.env.TRADING_MODE || 'paper',

  // Virtual bankroll for paper trading (USDC)
  PAPER_BANKROLL: 1000,

  // Position sizing per signal (% of bankroll)
  POSITION_SIZE_PCT: 0.05,   // 5% per trade
  MAX_OPEN_POSITIONS: 10,

  // Signal filters — signals outside these bounds are ignored
  FILTERS: {
    MIN_MARKET_LIQUIDITY: 5000,   // USDC
    MIN_SIGNAL_PRICE: 0.05,       // ignore near-certainty markets (>95c)
    MAX_SIGNAL_PRICE: 0.95,
    MAX_SIGNAL_AGE_HOURS: 2,      // don't copy stale signals
    MIN_MARKET_VOLUME_24H: 1000,
  },

  // Simulated costs to make paper results realistic
  SLIPPAGE_PCT: 0.003,   // 0.3%
  FEE_PCT: 0.002,        // 0.2% taker fee

  // Discovery / roster management
  DISCOVERY: {
    ROSTER_SIZE: 10,               // how many wallets to track at once
    MIN_CLOSED_POSITIONS: 20,      // minimum track record to qualify
    MIN_WIN_RATE: 0.55,
    MIN_ROI: 0.10,
    LOOKBACK_DAYS: 30,
  },

  // Polymarket public API (no auth needed for reads)
  API: {
    GAMMA_BASE: 'https://gamma-api.polymarket.com',
    CLOB_BASE:  'https://clob.polymarket.com',
    DATA_API:   'https://data-api.polymarket.com',
  },

  // Git branch used to persist SQLite state between GH Actions runs
  STATE_BRANCH: 'paper-state',
  DB_PATH: 'data/state.db',
};
