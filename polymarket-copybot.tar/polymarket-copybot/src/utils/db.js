// ─── Database layer (SQLite WASM, no native deps) ────────────────────────────
import { createRequire } from 'module';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { dirname } from 'path';
import { CONFIG } from '../../config.js';

const require = createRequire(import.meta.url);

let _db = null;

export async function getDb() {
  if (_db) return _db;

  const { Database } = await import('node-sqlite3-wasm');
  const dir = dirname(CONFIG.DB_PATH);
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });

  const db = new Database(
    existsSync(CONFIG.DB_PATH)
      ? readFileSync(CONFIG.DB_PATH)
      : undefined
  );

  db.persist = () => writeFileSync(CONFIG.DB_PATH, db.export());

  db.exec(`
    PRAGMA journal_mode = WAL;

    -- Tracked wallet roster
    CREATE TABLE IF NOT EXISTS wallets (
      address     TEXT PRIMARY KEY,
      added_at    INTEGER NOT NULL,
      active      INTEGER NOT NULL DEFAULT 1,
      win_rate    REAL,
      roi         REAL,
      pnl_total   REAL DEFAULT 0,
      score       REAL DEFAULT 0
    );

    -- Every signal detected from a tracked wallet
    CREATE TABLE IF NOT EXISTS signals (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      wallet        TEXT NOT NULL,
      market_id     TEXT NOT NULL,
      outcome       TEXT NOT NULL,
      action        TEXT NOT NULL,  -- 'open' | 'close' | 'increase'
      price         REAL NOT NULL,
      size          REAL NOT NULL,
      detected_at   INTEGER NOT NULL,
      processed     INTEGER NOT NULL DEFAULT 0
    );

    -- Paper trades (one row per simulated order)
    CREATE TABLE IF NOT EXISTS trades (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      signal_id     INTEGER REFERENCES signals(id),
      market_id     TEXT NOT NULL,
      outcome       TEXT NOT NULL,
      side          TEXT NOT NULL,  -- 'buy' | 'sell'
      size_usdc     REAL NOT NULL,
      price         REAL NOT NULL,
      fee           REAL NOT NULL,
      slippage      REAL NOT NULL,
      executed_at   INTEGER NOT NULL,
      status        TEXT NOT NULL DEFAULT 'open'  -- 'open' | 'closed'
    );

    -- Open positions (aggregated view kept in sync)
    CREATE TABLE IF NOT EXISTS positions (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      market_id     TEXT NOT NULL,
      outcome       TEXT NOT NULL,
      wallet        TEXT NOT NULL,
      avg_price     REAL NOT NULL,
      size_usdc     REAL NOT NULL,
      opened_at     INTEGER NOT NULL,
      UNIQUE(market_id, outcome, wallet)
    );

    -- Daily P&L snapshots (for reporting)
    CREATE TABLE IF NOT EXISTS snapshots (
      date          TEXT PRIMARY KEY,
      bankroll      REAL NOT NULL,
      pnl_day       REAL NOT NULL,
      pnl_total     REAL NOT NULL,
      open_positions INTEGER NOT NULL,
      win_rate      REAL,
      created_at    INTEGER NOT NULL
    );
  `);

  db.persist();
  _db = db;
  return db;
}

// Helper: run a SELECT and return all rows as plain objects
export function all(db, sql, params = []) {
  return db.all(sql, params);
}

// Helper: run INSERT/UPDATE/DELETE
export function run(db, sql, params = []) {
  return db.run(sql, params);
}
