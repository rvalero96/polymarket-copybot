// ─── Polymarket public API client ─────────────────────────────────────────────
// No authentication needed for read operations.
// Docs: https://docs.polymarket.com

import fetch from 'node-fetch';
import { CONFIG } from '../../../config.js';
import { logger } from '../../utils/logger.js';

const { GAMMA_BASE, CLOB_BASE, DATA_API } = CONFIG.API;

async function get(url, params = {}) {
  const qs = new URLSearchParams(params).toString();
  const full = qs ? `${url}?${qs}` : url;
  logger.debug('api:get', { url: full });
  const res = await fetch(full, { headers: { 'Accept': 'application/json' } });
  if (!res.ok) throw new Error(`API ${res.status} — ${full}`);
  return res.json();
}

// ── Wallet / positions ────────────────────────────────────────────────────────

/** Get all current open positions for a wallet */
export async function getWalletPositions(address) {
  return get(`${DATA_API}/positions`, { user: address, sizeThreshold: '0.01' });
}

/** Get full trade history for a wallet (paginated) */
export async function getWalletTrades(address, limit = 500) {
  return get(`${DATA_API}/activity`, { user: address, limit });
}

/** Get wallet P&L summary */
export async function getWalletPnL(address) {
  return get(`${DATA_API}/portfolio-performance`, { address });
}

// ── Markets ───────────────────────────────────────────────────────────────────

/** Get market details by condition_id or slug */
export async function getMarket(conditionId) {
  const data = await get(`${GAMMA_BASE}/markets`, { condition_id: conditionId });
  return data?.[0] ?? null;
}

/** Search active markets with filters */
export async function getActiveMarkets({ limit = 100, offset = 0 } = {}) {
  return get(`${GAMMA_BASE}/markets`, {
    active: 'true',
    closed: 'false',
    limit,
    offset,
  });
}

/** Get current orderbook prices for a token */
export async function getMidpointPrice(tokenId) {
  const data = await get(`${CLOB_BASE}/midpoint`, { token_id: tokenId });
  return parseFloat(data?.mid ?? 0);
}

// ── Leaderboard (for discovery) ───────────────────────────────────────────────

/** Get top traders from Polymarket leaderboard */
export async function getLeaderboard({ limit = 50, offset = 0 } = {}) {
  return get(`${DATA_API}/leaderboard`, {
    limit,
    offset,
    sortBy: 'profit',
  });
}
