// ─── Phase 2: Live trading via Polymarket CLOB ────────────────────────────────
// This file is a STUB — only activated when TRADING_MODE=live
// 
// Setup (Phase 2):
//   1. Create wallet at clob.polymarket.com and deposit USDC via Polygon
//   2. Generate API credentials by signing a message with your private key
//   3. Add secrets to GitHub repo: PRIVATE_KEY, CLOB_API_KEY,
//      CLOB_API_SECRET, CLOB_API_PASSPHRASE
//   4. Set TRADING_MODE=live in the workflow env vars
//   5. Uncomment and implement the functions below using @polymarket/clob-client
//
// npm install @polymarket/clob-client (add to package.json when ready)

import { logger } from '../../utils/logger.js';

export async function openPosition({ marketId, outcome, sizeUsdc, price }) {
  logger.warn('live:openPosition called but Phase 2 not implemented', {
    marketId, outcome, sizeUsdc, price,
  });
  // TODO Phase 2:
  // const { ClobClient } = await import('@polymarket/clob-client');
  // const client = new ClobClient(host, chainId, wallet, creds);
  // const order = await client.createMarketBuyOrder({ tokenID, amount });
  // return client.postOrder(order);
  throw new Error('Phase 2 not implemented yet');
}

export async function closePosition({ marketId, outcome, size, price }) {
  logger.warn('live:closePosition called but Phase 2 not implemented', {
    marketId, outcome, size, price,
  });
  throw new Error('Phase 2 not implemented yet');
}
